package com.example.stays;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class PropertyListActivity extends AppCompatActivity {

    private List<Property> propertyList;
    private RecyclerView recyclerView;
    private PropertyAdapter propertyAdapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_property_list);

        dbHelper = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerViewPropertyList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        propertyList = getPropertiesFromDatabase();

        propertyAdapter = new PropertyAdapter(propertyList);
        recyclerView.setAdapter(propertyAdapter);

        TextView textViewEmptyView = findViewById(R.id.textViewEmptyView);
        if (propertyList.isEmpty()) {
            textViewEmptyView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            textViewEmptyView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }

        FloatingActionButton fabAddProperty = findViewById(R.id.fabAddProperty);
        fabAddProperty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click to add a new property
                // (You can start a new activity to add a property, for example)
            }
        });
    }

    // Inside PropertyListActivity's getPropertiesFromDatabase() method
    // Inside PropertyListActivity's getPropertiesFromDatabase() method
    private List<Property> getPropertiesFromDatabase() {
        List<Property> properties = new ArrayList<>();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM property", null);
        if (cursor != null) {
            int addressIndex = cursor.getColumnIndex("address");
            int ratePerNightIndex = cursor.getColumnIndex("rate_per_night");
            int starRatingIndex = cursor.getColumnIndex("star_rating");
            int countryIndex = cursor.getColumnIndex("country");
            int locationIndex = cursor.getColumnIndex("location");

            while (cursor.moveToNext()) {
                String address = cursor.getString(addressIndex);
                double ratePerNight = cursor.getDouble(ratePerNightIndex);
                float starRating = cursor.getFloat(starRatingIndex);
                String country = cursor.getString(countryIndex);
                String location = cursor.getString(locationIndex);

                Property property = new Property(address, ratePerNight, starRating, country, location);
                properties.add(property);
            }
            cursor.close();
        }

        db.close(); // Close the database

        return properties;
    }

}
