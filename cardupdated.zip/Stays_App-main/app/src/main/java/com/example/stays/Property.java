package com.example.stays;

public class Property {
    private String address;
    private double ratePerNight;
    private float starRating;
    private String country;
    private String location;
    private double mileage;

    public Property(String address, double ratePerNight, float starRating, String country, String location) {
        this.address = address;
        this.ratePerNight = ratePerNight;
        this.starRating = starRating;
        this.country = country;
        this.location = location;
    }

    // Getters and setters for existing fields

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getRatePerNight() {
        return ratePerNight;
    }

    public void setRatePerNight(double ratePerNight) {
        this.ratePerNight = ratePerNight;
    }

    public float getStarRating() {
        return starRating;
    }

    public void setStarRating(float starRating) {
        this.starRating = starRating;
    }

    // Getters and setters for additional fields

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
