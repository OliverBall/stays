package com.example.stays;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.Locale;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PropertyAdapter extends RecyclerView.Adapter<PropertyAdapter.PropertyViewHolder> {

    private List<Property> propertyList;

    public PropertyAdapter(List<Property> propertyList) {
        this.propertyList = propertyList;
    }

    public void setPropertyList(List<Property> propertyList) {
        this.propertyList = propertyList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PropertyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.property_card_item, parent, false);
        return new PropertyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PropertyViewHolder holder, int position) {
        Property property = propertyList.get(position);
        holder.tvAddressLine1.setText(property.getAddress());
        holder.tvAddressLine2.setText(String.format("%s, %s", property.getCountry(), property.getLocation()));
        holder.tvRatePerNight.setText(String.format("£%.2f/night", property.getRatePerNight()));
        holder.tvRating.setText(String.format(Locale.getDefault(), "%.1f", property.getStarRating()));
    }

    @Override
    public int getItemCount() {
        return propertyList.size();
    }

    public static class PropertyViewHolder extends RecyclerView.ViewHolder {
        private TextView tvAddressLine1;
        private TextView tvAddressLine2;
        private TextView tvRatePerNight;
        private TextView tvRating;
        private TextView tvMileage;

        public PropertyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAddressLine1 = itemView.findViewById(R.id.tvAddressLine);
            tvAddressLine2 = itemView.findViewById(R.id.tvAddressLine2);
            tvRatePerNight = itemView.findViewById(R.id.tvRatePerNight);
            tvRating = itemView.findViewById(R.id.tvRating);
        }
    }
}


